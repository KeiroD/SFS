<?php
// Version: 0.1

global $helptxt, $txtJs;

//Common
$txt['sfs_spam_detected'] = 'L\'utente %s con indirizzo Email %s (IP %s) risulta essere uno Spam, contattare l\'Amministratore del forum.';

//SMF 1.x
$txt['sfs_txt_sfsenabled'] = 'Stop Forum Spam Abilitato';
$txt['sfs_txt_sfsenabled_desc'] = 'Abilita il controllo della Email dell\'utente in www.stopforumspam.com';
$txt['sfs_txt_ipcheck'] = 'Verifica l\'Indirizzo IP';
$txt['sfs_txt_ipcheck_desc'] = 'Abilita il controllo anche dell\'indirizzo IP';
$txt['sfs_txt_usernamecheck'] = 'Verifica l\'Username';
$txt['sfs_txt_usernamecheck_desc'] = 'Abilita il controllo anche dell\'Username';

//SMF 2.x
$txt['setting_sfs_enabled'] = 'Stop Forum Spam Abilitato';
$txt['setting_sfs_enabled_desc'] = 'Abilita il controllo della Email dell\'utente in www.stopforumspam.com';
$txt['setting_sfs_ipcheck'] = 'Verifica l\'Indirizzo IP';
$txt['setting_sfs_ipcheck_desc'] = 'Abilita il controllo anche dell\'indirizzo IP';
$txt['setting_sfs_usernamecheck'] = 'Verifica l\'Username';
$txt['setting_sfs_usernamecheck_desc'] = 'Abilita il controllo anche dell\'Username';
?>
