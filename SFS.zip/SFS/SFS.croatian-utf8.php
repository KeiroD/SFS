<?php
// Version: 0.1

global $helptxt, $txtJs;

//Common
$txt['sfs_spam_detected'] = 'Korisnik %s putem e-maila %s (IP %s) je spam, molimo kontaktirajte administratora foruma.';

//SMF 1.x
$txt['sfs_txt_sfsenabled'] = 'Stop Forum Spam Omogu&#263;eno';
$txt['sfs_txt_sfsenabled_desc'] = 'Omogu&#263;ite i provjerite e-po&#353;tu korisnika na <a href="http://www.stopforumspam.com">www.stopforumspam.com</a>';
$txt['sfs_txt_ipcheck'] = 'Provjerite tako&#273;er IP adresu';
$txt['sfs_txt_ipcheck_desc'] = 'Omogu&#263;i provjeru IP';
$txt['sfs_txt_usernamecheck'] = 'Provjerite tako&#273;er Korisni&#269;ko ime';
$txt['sfs_txt_usernamecheck_desc'] = 'Omogu&#263;i provjeru Korisni&#269;kog imena';

//SMF 2.x
$txt['setting_sfs_enabled'] = 'Stop Forum Spam Omogu&#263;eno';
$txt['setting_sfs_enabled_desc'] = 'Omogu&#263;ite i provjerite e-po&#353;tu korisnika na <a href="http://www.stopforumspam.com">www.stopforumspam.com</a>';
$txt['setting_sfs_ipcheck'] = 'Provjerite tako&#273;er IP adresu';
$txt['setting_sfs_ipcheck_desc'] = 'Omogu&#263;i provjeru IP';
$txt['setting_sfs_usernamecheck'] = 'Provjerite tako&#273;er Korisni&#269;ko ime';
$txt['setting_sfs_usernamecheck_desc'] = 'Omogu&#263;i provjeru Korisni&#269;kog imena';
?>
