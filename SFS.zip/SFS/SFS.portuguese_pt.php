<?php
// Version: 0.1

global $helptxt, $txtJs;

//common
$txt['sfs_spam_detected'] = 'O utilizador %s com e-mail %s (IP %s) &eacute; um spam, por favor contacte administrador do f&oacute;rum.';

//SMF 1.x
$txt['sfs_txt_sfsenabled'] = 'Activar o Stop Forum Spam';
$txt['sfs_txt_sfsenabled_desc'] = 'Habilitar verificar se o utilizador est&aacute; no e-mail www.stopforumspam.com';
$txt['sfs_txt_ipcheck'] = 'Verifique tamb&eacute;m o endere&ccedil;o IP';
$txt['sfs_txt_ipcheck_desc'] = 'Activar a verificar do IP';
$txt['sfs_txt_usernamecheck'] = 'Verifique tamb&eacute;m o nome do utilizador';
$txt['sfs_txt_usernamecheck_desc'] = 'Activar verifica&ccedil;&atilde;o do Utilizador';

//SMF 2.x
$txt['setting_sfs_enabled'] = 'Activar o Stop Forum Spam';
$txt['setting_sfs_enabled_desc'] = 'Habilitar verificar se o utilizador est&aacute; no e-mail www.stopforumspam.com';
$txt['setting_sfs_ipcheck'] = 'Verifique tamb&eacute;m o endere&ccedil;o IP';
$txt['setting_sfs_ipcheck_desc'] = 'Activar a verificar do IP';
$txt['setting_sfs_usernamecheck'] = 'Verifique tamb&eacute;m o nome do utilizador';
$txt['setting_sfs_usernamecheck_desc'] = 'Activar verifica&ccedil;&atilde;o do Utilizador';
?>
